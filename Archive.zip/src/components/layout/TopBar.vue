<script setup lang="ts">
import { ref, onMounted, onUnmounted } from "vue";
import { useInvoiceStore } from "../../stores/invoice.store";
import { buildShareUrl } from "../../utils/shareLink";
import { clearDraftStorage } from "../../composables/useAutosave";
import ConfirmDialog from "../form/ConfirmDialog.vue";

const store = useInvoiceStore();
const lastUpdated = ref(new Date());
const toast = ref("");
const isResetConfirmOpen = ref(false);
let toastTimer: ReturnType<typeof setTimeout> | null = null;
let unsubscribe: (() => void) | null = null;

onMounted(() => {
  unsubscribe = store.$subscribe(() => {
    lastUpdated.value = new Date();
  });
});

onUnmounted(() => {
  unsubscribe?.();
  if (toastTimer) clearTimeout(toastTimer);
});

function showToast(message: string) {
  toast.value = message;
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (toast.value = ""), 2400);
}

async function generateLink() {
  const url = buildShareUrl(store.$state);
  try {
    await navigator.clipboard.writeText(url);
    showToast("لینک فاکتور در کلیپ‌بورد کپی شد");
  } catch {
    window.prompt("لینک فاکتور را کپی کنید:", url);
  }
}

function downloadPdf() {
  window.print();
}

function confirmReset() {
  store.reset();
  clearDraftStorage();
  isResetConfirmOpen.value = false;
  showToast("فرم بازنشانی شد");
}

const formattedUpdated = () =>
  new Intl.DateTimeFormat("fa-IR", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(lastUpdated.value);
</script>

<template>
  <header class="topbar">
    <div class="topbar__brand">
      <h1 class="topbar__title">فاکتور ساز</h1>
      <p class="topbar__subtitle">صدور رایگان و آسان فاکتور فروش</p>
      <nav class="topbar__links">
        <button type="button" class="link-btn" @click="isResetConfirmOpen = true">بازنشانی فرم</button>
      </nav>
    </div>

    <div class="topbar__actions">
      <div class="topbar__buttons">
        <button type="button" class="btn btn--ghost" @click="generateLink">ایجاد لینک فاکتور</button>
        <button type="button" class="btn btn--dark" @click="downloadPdf">دانلود PDF</button>
      </div>
      <span class="topbar__updated">آخرین بروزرسانی: {{ formattedUpdated() }}</span>
    </div>

    <Transition name="toast-fade">
      <div v-if="toast" class="toast">{{ toast }}</div>
    </Transition>

    <ConfirmDialog
      v-if="isResetConfirmOpen"
      title="بازنشانی فرم"
      message="تمام اطلاعات وارد شده — فروشنده، خریدار، ردیف‌ها و تنظیمات — پاک خواهد شد. این عمل قابل بازگشت نیست."
      confirm-label="بازنشانی"
      @confirm="confirmReset"
      @cancel="isResetConfirmOpen = false"
    />
  </header>
</template>

<style scoped>
.topbar {
  position: relative;
  flex: 0 0 auto;
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 14px;
  padding: 10px 16px;
  background: var(--surface);
  border-bottom: 1px solid var(--line);
  flex-wrap: wrap;
}

.topbar__brand {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.topbar__title {
  margin: 0;
  font-size: 15px;
  font-weight: 800;
}

.topbar__subtitle {
  margin: 0;
  font-size: 10.5px;
  color: var(--ink-muted);
}

.topbar__links {
  margin-top: 3px;
}

.link-btn {
  border: none;
  background: transparent;
  padding: 0;
  font-size: 10.5px;
  color: var(--ink-muted);
  text-decoration: underline;
}

.link-btn:hover {
  color: var(--ink);
}

.topbar__actions {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 5px;
}

.topbar__buttons {
  display: flex;
  gap: 7px;
}

.btn {
  border-radius: 7px;
  padding: 7px 13px;
  font-size: 11.5px;
  font-weight: 600;
  border: 1px solid transparent;
  white-space: nowrap;
}

.btn--ghost {
  background: #fff;
  border-color: var(--line);
  color: var(--ink);
}

.btn--ghost:hover {
  border-color: #111111;
}

.btn--dark {
  background: #111111;
  color: #fff;
}

.btn--dark:hover {
  background: #2b2b2b;
}

.topbar__updated {
  font-size: 10px;
  color: var(--ink-muted);
}

.toast {
  position: absolute;
  bottom: -40px;
  left: 50%;
  transform: translateX(-50%);
  background: #111111;
  color: #fff;
  padding: 8px 16px;
  border-radius: 999px;
  font-size: 12px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
  z-index: 20;
}

.toast-fade-enter-active,
.toast-fade-leave-active {
  transition: opacity 0.2s ease, transform 0.2s ease;
}

.toast-fade-enter-from,
.toast-fade-leave-to {
  opacity: 0;
  transform: translate(-50%, -6px);
}

@media (max-width: 640px) {
  .topbar {
    flex-direction: column;
    align-items: stretch;
  }

  .topbar__actions {
    align-items: flex-start;
  }
}
</style>
