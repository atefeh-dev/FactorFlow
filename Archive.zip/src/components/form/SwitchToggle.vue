<script setup lang="ts">
const props = defineProps<{
  modelValue: boolean;
  label?: string;
}>();

const emit = defineEmits<{
  "update:modelValue": [value: boolean];
}>();

function toggle() {
  emit("update:modelValue", !props.modelValue);
}
</script>

<template>
  <label class="switch-row">
    <span v-if="label" class="switch-row__label">{{ label }}</span>
    <button
      type="button"
      role="switch"
      :aria-checked="modelValue"
      class="switch"
      :class="{ 'switch--on': modelValue }"
      @click="toggle"
    >
      <span class="switch__thumb" />
    </button>
  </label>
</template>

<style scoped>
.switch-row {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  cursor: pointer;
  user-select: none;
}

.switch-row__label {
  font-size: 10.5px;
  color: var(--ink-muted);
  font-weight: 500;
}

.switch {
  width: 30px;
  height: 18px;
  border-radius: 999px;
  border: 1px solid var(--line);
  background: var(--surface-muted);
  position: relative;
  padding: 0;
  transition: background 0.15s ease, border-color 0.15s ease;
  flex-shrink: 0;
}

.switch--on {
  background: #111111;
  border-color: #111111;
}

.switch__thumb {
  position: absolute;
  top: 1px;
  right: 1px;
  width: 14px;
  height: 14px;
  border-radius: 50%;
  background: #fff;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.25);
  transition: transform 0.15s ease;
}

.switch--on .switch__thumb {
  transform: translateX(-12px);
}
</style>
